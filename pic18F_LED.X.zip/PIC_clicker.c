/*
 * Project name:
     PIC clicker (Simple 'Hello World' project)
 * Copyright:
     (c) Mikroelektronika, 2011.
 * Revision History:
     20130906:
       - initial release (JK);
 * Description:
     This is a simple 'Hello World' project. It turns on/off LEDs connected to
     RA0 and RA1 pins depending on pressed buttons. Left button T1 changes mode
     of blinking and right button changes frequency of blinking.
 * Test configuration:
     MCU:             PIC18F47J53
                      http://ww1.microchip.com/downloads/en/DeviceDoc/39964B.pdf
     Dev.Board:       PIC clicker - ac:PIC_clicker
                      http://www.mikroe.com/pic/clicker/
     Oscillator:      HS-PLL 48.0000 MHz, 16.0000 MHz Crystal
     Ext. Modules:    None.
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/mikroc/pic/
 */
#include <xc.h>        /* XC8 General Include File */
#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */
#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp */
//>>>#include pic18f47j53.h

#define LED1_On  asm("BSF LATA,0")
#define LED2_On  asm("BSF LATA,1")
#define LED1_Off  asm("BCF LATA,0")
#define LED2_Off  asm("BCF LATA,1")
#define LED1_Toggle asm("BTG LATA,0")
#define LED2_Toggle asm("BTG LATA,1")

/* pin definitions
sbit LD1 at LATA0_bit;
#define LD1_Toggle asm("BTG LATDA,0 ")
#define LD1_Off asm("BCF LATDA,0 ")
#define LD1_On asm("BSF LATDA,0 ")

sbit LD2 at LATA1_bit;
sbit LD1_Direction at TRISA0_bit;
sbit LD2_Direction at TRISA1_bit;

sbit T1 at RD3_bit;
sbit T2 at RD2_bit;
sbit T1_Direction at TRISD3_bit;
sbit T2_Direction at TRISD2_bit; */

// globals
char oldstate1 = 0, oldstate2 = 0;
char Example_State = 0;
char count;

//Timer0
//Prescaler 1:128; TMR0 Preload = 18660; Actual Interrupt Time : 500 ms
void InitTimer0(){
  T0CON         = 0x86;
  TMR0H         = 0x48;
  TMR0L         = 0xE4;
//  INTCON.GIE_bit = 1;
//  RCONbits.IPEN = 0;
//         
  INTCON |= 0x80;   //GIE_bit       = 1;
  INTCON |= 0x20;   //TMR0IE_bit    = 1;
//->  INTCON |= 0xA0;
}

// ISR
void __interrupt() ISRv(){
char temp;
  // check for timer0 interrupt
//  if (TMR0IF_bit){
if (INTCON & 0x04){
    // clear timer0 Interrupt flag
//    TMR0IF_bit = 0;
      INTCON &= 0xFB;
  LED1_Toggle;
    // check T1 button state
/*    switch (Example_State & 0x0F){
      case 0 :
//               LD1 = 0;                     // Both LEDs are OF
//               LD2 = 0;
               LED1_Off;
               LED2_Off;
               break;
      case 1 : LD1 ^= 1;                    // Only LD1 blinks
               LD2 = 0;
               LED1_Toggle;
               LED2_Off;
               break;
      case 2 : LD1 = 0;                     // Only LD2 blinks
               LD2 ^= 1;
               LED1_Off;
               LED2_Toggle;
               break;
      case 3 : LD1 ^= 1;                    // Both LEDs blinks alternately
               LD2  = !LD1;
               LED1_Toggle;
               LED2_Toggle;
               break;
      case 4 : LD1 ^= 1;                    // Both LEDs blink simultaneously
               LD2  = LD1;
               LED1_Toggle;
               LED2_Toggle;
               break;
      default : Example_State &= 0xF0;      // reset T1 state to zero
                break;
    }
    // check T2 button state
    switch (Example_State & 0xF0){
      case 0x00 : TMR0H = 0x48;             // Set Timer0 Interrupt time to 500ms
                  TMR0L = 0xE4;
                  break;
      case 0x10 : TMR0H = 0x6D;             // Set Timer0 Interrupt time to 400ms
                  TMR0L = 0x83;
                  break;
      case 0x20 : TMR0H = 0x92;             // Set Timer0 Interrupt time to 300ms
                  TMR0L = 0x22;
                  break;
      case 0x30 : TMR0H = 0xB6;             // Set Timer0 Interrupt time to 200ms
                  TMR0L = 0xC1;
                  break;
      case 0x40 : TMR0H = 0xDB;             // Set Timer0 Interrupt time to 100ms
                  TMR0L = 0x60;
                  break;
      default :   TMR0H = 0x48;             // Set Timer0 Interrupt time to 500ms
                  TMR0L = 0xE4;
                  Example_State &= 0x0F;    // reset T1 state to zero
                break;
    } */
  }
}

// main function
void main() {
  ANCON0 = 0;               // Default all pins to digital
  ANCON1 = 0;
     /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize I/O and Peripherals for application */
    InitApp();

    /* TODO <INSERT USER APPLICATION CODE HERE> */
 //T1_Direction = 1;         // Set direction for buttons -TRISD3_bit
  asm("BSF TRISD,3");
 //T2_Direction = 1;
  asm("BSF TRISD,2");  
  //LD1_Direction = 0;        // Set direction for LEDS
  asm("BCF TRISA,0");
  //LD2_Direction = 0;
  asm("BCF TRISA,1");
  //LD1 = 0;                  // turn off leds
  LED1_Off;
  //LD2 = 0;
  LED2_Off;
  Example_State = 0;        // set default Example state

  InitTimer0();             // initialize timer0

  while(1){                 // Endless loop
    // check T1 button
    if (!(PORTD & 0B00001000 )) {
  LED1_On;
  LED2_Off;
    }
   if (!(PORTD & 0B00000100 )) {
  LED1_Off;
  LED2_On;
    }
//    if (Button(&PORTD, 3, 2, 0)) {                // Detect logical zero
//    if(PORTD & 0b00001000) {   
//      oldstate1 ^= 0b00001000;                              // Update flag
//    }
//    if (oldstate1 && Button(&PORTD, 3, 2, 1)) {   // Detect zero-to-one transition
    if (!oldstate1 & PORTD & 0B00001000 ) {
//      oldstate1 = 0;                              // Update flag
      Example_State += 0x01;                      // set new Example state
      if ((Example_State & 0x0F) > 4)
        Example_State &= 0xF0;
    }
    // check T2 button
//    if (Button(&PORTD, 2, 2, 0)) {                // Detect logical zero
    if (!oldstate1 & PORTD & 0B00000100 ) {
//      oldstate2 = 1;                              // Update flag
//    }
//    if (oldstate2 && Button(&PORTD, 2, 2, 1)) {   // Detect zero-to-one transition
//     oldstate2 = 0;                              // Update flag
      Example_State += 0x10;                      // set new Example state
      if ((Example_State & 0xF0) > 0x40)
        Example_State &= 0x0F;
    }
    oldstate1 = PORTD;
  }
}